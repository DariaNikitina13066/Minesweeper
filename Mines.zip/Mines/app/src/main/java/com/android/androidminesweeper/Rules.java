package com.android.androidminesweeper;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

public class Rules extends AppCompatActivity {
    public void GoBack(View view){
        Intent Back = new Intent(this, MainActivity.class);
        startActivity(Back);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rules);
    }
}
