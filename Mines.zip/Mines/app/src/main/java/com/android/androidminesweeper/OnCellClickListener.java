package com.android.androidminesweeper;

public interface OnCellClickListener {
    void cellClick(Cell cell);
}
